﻿using System;

namespace L11_MAPJ_1127821
{
    class Program
    {
        static void Main(string[] args)
        {
            double cambio = 0;
            Console.WriteLine("Ingrese la cantidad que desea comvertir");
            Console.WriteLine("Libras");
            Console.WriteLine("Dolares");
            Console.WriteLine("Yenes");
            cambio = double.Parse(Console.ReadLine());
            Console.ReadKey();
            ConversionMoneda(cambio);
        }
        static void ConversionMoneda(double cambio);

        double libra = 1.22,dolares = 0.75,yenes = 0.009,cambiolibras = 0,resultlibras = 0,cambiodolares = 0,resultdolares = 0,cambyenes = 0,resultyenes = 0;
        if (cambio)
            {
             Console.WriteLine("convertir de libras a euros");
            cambiolibras = double.Parse(Console.ReadLine());
        euros = libras* 1.22;
            Console.WriteLine("Su cambio es de", libras, euros);
            Console.ReadKey();
            
            Console.WriteLine("convertir de dolares a euros");
            cambiodolares - double.Parse(Console.ReadLine());
        euros = dolares* 0.75;
            Console.WriteLine("Su cambio es de", dolares, euros);
            Console.ReadKey();

            Console.WriteLine("convertir de yenes a euros");
            cambyenes = double.Parse(Console.ReadLine());
        euros = yenes*0.009
            Console.WriteLine("Su cambio es de", yenes, euros);
            Console.ReadKey();

           }

    }            
}






   

