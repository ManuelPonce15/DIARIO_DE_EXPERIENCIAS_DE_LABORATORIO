﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_MPJ_1127821
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string marca;
            int modelo;
            int precio;
            string disponibilidad;
            int descuento;
            int cambiodolar;
            if (!int.TryParse(txt_precio.Text, out int num))
                if (!int.TryParse(txt_descuento.Text, out int numero))
                {
                    MessageBox.Show("Debe ingresar un numero");
                }
                else
                {
                    precio = Convert.ToInt32(txt_precio.Text);
                }
            {
                MessageBox.Show("Debe ingresar un numero");
            }
            else 
            {
                descuento = Convert.ToInt32(txt_descuento.Text);
            }
        }
    }
}
