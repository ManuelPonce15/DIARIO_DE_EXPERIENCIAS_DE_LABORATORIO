﻿
namespace L9_MPJ_1127821
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_marca = new System.Windows.Forms.Label();
            this.txt_precio = new System.Windows.Forms.TextBox();
            this.txt_disponible = new System.Windows.Forms.TextBox();
            this.txt_descuento = new System.Windows.Forms.TextBox();
            this.txt_modelo = new System.Windows.Forms.TextBox();
            this.txt_tipodolar = new System.Windows.Forms.TextBox();
            this.txt_marca = new System.Windows.Forms.TextBox();
            this.lbl_modelo = new System.Windows.Forms.Label();
            this.lbl_precio = new System.Windows.Forms.Label();
            this.lbl_disponible = new System.Windows.Forms.Label();
            this.lbl_tipodolar = new System.Windows.Forms.Label();
            this.lbl_descuento = new System.Windows.Forms.Label();
            this.Guardar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_marca
            // 
            this.lbl_marca.AutoSize = true;
            this.lbl_marca.Location = new System.Drawing.Point(122, 102);
            this.lbl_marca.Name = "lbl_marca";
            this.lbl_marca.Size = new System.Drawing.Size(74, 25);
            this.lbl_marca.TabIndex = 1;
            this.lbl_marca.Text = "MARCA";
            this.lbl_marca.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_precio
            // 
            this.txt_precio.Location = new System.Drawing.Point(435, 145);
            this.txt_precio.Name = "txt_precio";
            this.txt_precio.Size = new System.Drawing.Size(150, 31);
            this.txt_precio.TabIndex = 2;
            // 
            // txt_disponible
            // 
            this.txt_disponible.Location = new System.Drawing.Point(66, 259);
            this.txt_disponible.Name = "txt_disponible";
            this.txt_disponible.Size = new System.Drawing.Size(150, 31);
            this.txt_disponible.TabIndex = 3;
            // 
            // txt_descuento
            // 
            this.txt_descuento.Location = new System.Drawing.Point(473, 259);
            this.txt_descuento.Name = "txt_descuento";
            this.txt_descuento.Size = new System.Drawing.Size(150, 31);
            this.txt_descuento.TabIndex = 4;
            // 
            // txt_modelo
            // 
            this.txt_modelo.Location = new System.Drawing.Point(260, 145);
            this.txt_modelo.Name = "txt_modelo";
            this.txt_modelo.Size = new System.Drawing.Size(150, 31);
            this.txt_modelo.TabIndex = 5;
            // 
            // txt_tipodolar
            // 
            this.txt_tipodolar.Location = new System.Drawing.Point(260, 259);
            this.txt_tipodolar.Name = "txt_tipodolar";
            this.txt_tipodolar.Size = new System.Drawing.Size(150, 31);
            this.txt_tipodolar.TabIndex = 6;
            // 
            // txt_marca
            // 
            this.txt_marca.Location = new System.Drawing.Point(75, 145);
            this.txt_marca.Name = "txt_marca";
            this.txt_marca.Size = new System.Drawing.Size(150, 31);
            this.txt_marca.TabIndex = 7;
            // 
            // lbl_modelo
            // 
            this.lbl_modelo.AutoSize = true;
            this.lbl_modelo.Location = new System.Drawing.Point(296, 102);
            this.lbl_modelo.Name = "lbl_modelo";
            this.lbl_modelo.Size = new System.Drawing.Size(74, 25);
            this.lbl_modelo.TabIndex = 8;
            this.lbl_modelo.Text = "Modelo";
            // 
            // lbl_precio
            // 
            this.lbl_precio.AutoSize = true;
            this.lbl_precio.Location = new System.Drawing.Point(462, 102);
            this.lbl_precio.Name = "lbl_precio";
            this.lbl_precio.Size = new System.Drawing.Size(60, 25);
            this.lbl_precio.TabIndex = 9;
            this.lbl_precio.Text = "Precio";
            // 
            // lbl_disponible
            // 
            this.lbl_disponible.AutoSize = true;
            this.lbl_disponible.Location = new System.Drawing.Point(98, 215);
            this.lbl_disponible.Name = "lbl_disponible";
            this.lbl_disponible.Size = new System.Drawing.Size(97, 25);
            this.lbl_disponible.TabIndex = 10;
            this.lbl_disponible.Text = "Disponible";
            // 
            // lbl_tipodolar
            // 
            this.lbl_tipodolar.AutoSize = true;
            this.lbl_tipodolar.Location = new System.Drawing.Point(285, 215);
            this.lbl_tipodolar.Name = "lbl_tipodolar";
            this.lbl_tipodolar.Size = new System.Drawing.Size(141, 25);
            this.lbl_tipodolar.TabIndex = 11;
            this.lbl_tipodolar.Text = "Tipo de cambio ";
            // 
            // lbl_descuento
            // 
            this.lbl_descuento.AutoSize = true;
            this.lbl_descuento.Location = new System.Drawing.Point(473, 215);
            this.lbl_descuento.Name = "lbl_descuento";
            this.lbl_descuento.Size = new System.Drawing.Size(96, 25);
            this.lbl_descuento.TabIndex = 12;
            this.lbl_descuento.Text = "Descuento";
            // 
            // Guardar
            // 
            this.Guardar.Location = new System.Drawing.Point(168, 349);
            this.Guardar.Name = "Guardar";
            this.Guardar.Size = new System.Drawing.Size(112, 34);
            this.Guardar.TabIndex = 13;
            this.Guardar.Text = "Guardar";
            this.Guardar.UseVisualStyleBackColor = true;
            this.Guardar.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(379, 349);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 34);
            this.button2.TabIndex = 14;
            this.button2.Text = "Limpiar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Guardar);
            this.Controls.Add(this.lbl_descuento);
            this.Controls.Add(this.lbl_tipodolar);
            this.Controls.Add(this.lbl_disponible);
            this.Controls.Add(this.lbl_precio);
            this.Controls.Add(this.lbl_modelo);
            this.Controls.Add(this.txt_marca);
            this.Controls.Add(this.txt_tipodolar);
            this.Controls.Add(this.txt_modelo);
            this.Controls.Add(this.txt_descuento);
            this.Controls.Add(this.txt_disponible);
            this.Controls.Add(this.txt_precio);
            this.Controls.Add(this.lbl_marca);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_marca;
        private System.Windows.Forms.TextBox txt_precio;
        private System.Windows.Forms.TextBox txt_disponible;
        private System.Windows.Forms.TextBox txt_descuento;
        private System.Windows.Forms.TextBox txt_modelo;
        private System.Windows.Forms.TextBox txt_tipodolar;
        private System.Windows.Forms.TextBox txt_marca;
        private System.Windows.Forms.Label lbl_modelo;
        private System.Windows.Forms.Label lbl_precio;
        private System.Windows.Forms.Label lbl_disponible;
        private System.Windows.Forms.Label lbl_tipodolar;
        private System.Windows.Forms.Label lbl_descuento;
        private System.Windows.Forms.Button Guardar;
        private System.Windows.Forms.Button button2;
    }
}

