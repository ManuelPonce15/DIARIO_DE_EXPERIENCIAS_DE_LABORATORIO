﻿using System;

namespace Laboratorio12_MAPJ_1127821
{
    class Program
    {
            static void Main(string[] args)
            {
                Console.WriteLine("Laboratorio 12");
                pruebaVector pv = new pruebaVector();
                pv.Cargar();
                pv.Imprimir();
            }

            class pruebaVector
            {
                private int[] notas;
                public int suma = 0;
                public void Cargar()
                {

                    notas = new int[15];
                    for (int a = 0; a < 15; a++)

                    {
                        Console.WriteLine("Ingresa una nota ");
                        string linea;
                        linea = Console.ReadLine();
                        notas[a] = int.Parse(linea);
                        suma = suma + notas[a];
                        int promedio = 0;
                    }
                }
                public void Imprimir()
                {
                    for (int a = 0; a < 15; a++)
                    {

                    }
                    Console.WriteLine("La suma es : " + suma);
                    Console.ReadKey();
                    for (int a = 0; a < 15; a++)
                    {
                        int promedio = 0;
                        promedio = notas[a = 0] + notas[a = 1] + notas[a = 2] + notas[a = 3] + notas[a = 4] + notas[a = 5] + notas[a = 6] + notas[a = 7] + notas[a = 8] + notas[a = 9] + notas[a = 10] + notas[a = 11] + notas[a = 12] + notas[a = 13] + notas[a = 14] + notas[a = 15] / 2;
                    }
                    Console.WriteLine("El promedio es de:" + promedio);
                    Console.ReadKey();

                }

            }
        }
    }



