﻿using System;

namespace L5_MP_1127821
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroEntero;
            /*mensajes en pantalla*/
            Console.WriteLine("Ejercicio 1");
            Console.WriteLine("Ingrese un numero entero");
            /*siguiente instruccion recibe y almacena el numero */
            numeroEntero = Convert.ToInt32(Console.ReadLine());

            if (numeroEntero > 0)
            {
                Console.WriteLine("Resultlado positivo");
            }
            if (numeroEntero < 0)
            {
                Console.WriteLine("Resultado negativo");
            }
             if (numeroEntero == 0)
            {
                Console.WriteLine("es igual a 0");
            }

            
        }
    }
}
