﻿using System;

namespace L14_MAPJ_1127821
{
    class Program
    {
        static void Main(string[] args)
        {

            int opcion = 0;


            Console.WriteLine("Selecione una de las 3 opciones para comenzar");
            Console.WriteLine("1. Calcular edades");
            Console.WriteLine("2. Puestos y salarios");
            Console.WriteLine("3. Salir ");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    string[] nombres = new string[5];
                    int[] edades = new int[5];
                    int[] calculo = new int[5];


                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Ingrese el nombre de la persona");
                        nombres[i] = Console.ReadLine();
                        Console.WriteLine("Ingrese el año que nació " + nombres[i]);
                        edades[i] = int.Parse(Console.ReadLine());
                        calculo[i] = 2022 - edades[i];
                    }
                    Console.WriteLine("");
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine(nombres[i] + " tiene: " + calculo[i] + " años");
                    }

                    break;

                case 2:
                    string[] puesto = new string[5];
                    double[] salario = new double[5];
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Ingrese el nombre del puesto");
                        puesto[i] = Console.ReadLine();
                        Console.WriteLine("Ingrese el salario del puesto " + puesto[i]);
                        salario[i] = double.Parse(Console.ReadLine());
                    }

                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine(puesto[i] + " Su salario es de: " + salario[i]);
                    }
                    break;

                case 3:
                    Environment.Exit(0);
                    break;
            }
            }
    }
}