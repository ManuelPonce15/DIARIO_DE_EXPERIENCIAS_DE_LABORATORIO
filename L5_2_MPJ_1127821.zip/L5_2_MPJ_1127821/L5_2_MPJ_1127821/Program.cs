﻿using System;

namespace L5_2_MPJ_1127821
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroEntero;
            /*mensajes en pantalla*/
            Console.WriteLine("Ejercicio 2");
            Console.WriteLine("Ingrese un numero del 1-7");
            /*siguiente instruccion recibe y almacena el numero */
            numeroEntero = Convert.ToInt32(Console.ReadLine());

            if (numeroEntero == 1)
            {
                Console.WriteLine("Lunes");
            }
            if (numeroEntero ==2)
            {
                Console.WriteLine("Martes");
            }
            if (numeroEntero == 3)
            {
                Console.WriteLine("Miercoles");
            }
            if (numeroEntero == 4)
            {
                Console.WriteLine("Jueves");
            }
            if (numeroEntero == 5)
            {
                Console.WriteLine("viernes");
            }
            if (numeroEntero == 6)
            {
                Console.WriteLine("Sabado");
            }
            if (numeroEntero == 7)
            {
                Console.WriteLine("Domingo");
            }
        }
    }
}
