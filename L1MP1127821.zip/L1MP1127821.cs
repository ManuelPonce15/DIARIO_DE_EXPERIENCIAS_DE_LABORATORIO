﻿using System;

namespace Laboratorio_1_22
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre:");
            String Nombre = Console.ReadLine();

            /*COMENTARIOS*/

            Console.Write("Hola Mundo");
            Console.Write("Soy " + Nombre);
            Console.ReadKey();
        }
    }
}
