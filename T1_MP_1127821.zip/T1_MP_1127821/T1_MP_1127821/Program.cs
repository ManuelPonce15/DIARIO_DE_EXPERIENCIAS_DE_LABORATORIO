﻿using System;

namespace T1_MP_1127821
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            
      

            /* COMENTARIOS */

            Console.WriteLine("Ingre los datos que se le piden");
            Console.WriteLine("Nombre" );
            string Nombre = Console.ReadLine(); 
            Console.WriteLine("Edad" );
            string Edad = Console.ReadLine();
            Console.WriteLine("Carnet"  );
            string Carnet = Console.ReadLine();
            Console.WriteLine("Carrera" );
            string Carrera = Console.ReadLine();
            Console.ReadKey();

            Console.WriteLine("Hola soy:" + Nombre + ", tengo," + Edad + ", años. Estudio la carrera de " + Carrera + ", y mi numero de carnet es:" + Carnet); 
            Console.ReadKey();

        }
    }
}
